<?php

namespace ScssPhp\ScssPhp\Exception;

interface SassException
{
}
